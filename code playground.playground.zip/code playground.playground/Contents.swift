import UIKit

struct Constants{
    static let myName = "tawanda"
    let mySurname = "chandiwana"
    
}
let myConstant = Constants()
print(myConstant.mySurname)
Constants.myName


                //CLOSURES//
let myClosure = {
    print("my closure with no parameters")
}
myClosure()

            //CLOSURES WITH PARAMTERS

let closureWithParameters = { (name:String) in
    print("hie \(name)")
}
closureWithParameters("tawanda")

//OR

let closureWithParamter:(String)-> () = {
    name in
    print("hello \(name)")
}
closureWithParamter("chibaba")

            //CLOSURES THAT RETURN SOMETHING

let sumClosure: (Int,Int) -> Int = {
    (num1, num2) in
    return num1 + num2 //return key can be removed if the closure returns 1 line of code
}
sumClosure(9,4)


            //CLOSURES AS FUNCTION PARAMETERS

//trailing closures
func sayHello (to name: String, finalGreeting:(String)-> Void){
    let name = name.uppercased()
    finalGreeting(name)
}
//in line closures
sayHello(to: "Mr Tawanda") {name in
    print("hello \(name)")
}
 //OR
//variable that is a closure
let sayIt: (String)-> Void = {
    name in
    print("hello \(name)")
}

sayHello(to: "Mr T", finalGreeting: sayIt)


//escaping closures
// closure which outlives the code it was called in
func sayHieInEscapingClosure(name: String,  greeting: @escaping(String)-> Void){
    let theName = name.uppercased()
    DispatchQueue.main.asyncAfter(deadline: .now() + 3 , execute: {
        greeting(theName)
    })
}
sayHieInEscapingClosure(name: "tawanda") { name in
    print(name)
}

//closures that store a value
//closures are reference types like classes


func gameCounter ()-> () -> Void {
    var counter = 0
    return {
        print("the counter is \(counter)")
        counter += 1
    }
}
let myCounter = gameCounter()
 myCounter()
 myCounter()
myCounter()
